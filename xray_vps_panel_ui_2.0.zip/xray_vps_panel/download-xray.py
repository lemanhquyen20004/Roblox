#!/usr/bin/env python3
import os
import platform
import shutil
import zipfile

import requests

API_URL = "https://api.github.com/repos/XTLS/Xray-core/releases/latest"


def get_asset_name():
    system = platform.system().lower()
    arch = platform.machine().lower()

    if system == "linux":
        if arch in {"x86_64", "amd64", "x64"}:
            return "Xray-linux-64.zip", "xray"
        if arch in {"aarch64", "arm64"}:
            return "Xray-linux-arm64-v8a.zip", "xray"
    raise RuntimeError(f"Unsupported platform: {system}/{arch}. This VPS build supports Linux amd64 and arm64.")


def latest_release():
    r = requests.get(API_URL, timeout=20, headers={"Accept": "application/vnd.github+json"})
    r.raise_for_status()
    data = r.json()
    return data["tag_name"], data.get("assets", [])


def install_xray():
    asset_name, binary_name = get_asset_name()
    version, assets = latest_release()
    match = next((a for a in assets if a.get("name") == asset_name), None)
    if not match:
        raise RuntimeError(f"Could not find {asset_name} in Xray release {version}")

    url = match["browser_download_url"]
    zip_path = "xray.zip"
    extract_dir = "xray_bin"

    print(f"[*] Latest Xray: {version}")
    print(f"[*] Downloading: {asset_name}")
    with requests.get(url, stream=True, timeout=60) as r:
        r.raise_for_status()
        with open(zip_path, "wb") as f:
            for chunk in r.iter_content(chunk_size=1024 * 256):
                if chunk:
                    f.write(chunk)

    shutil.rmtree(extract_dir, ignore_errors=True)
    os.makedirs(extract_dir, exist_ok=True)
    with zipfile.ZipFile(zip_path, "r") as zf:
        zf.extractall(extract_dir)
    os.remove(zip_path)

    src = os.path.join(extract_dir, binary_name)
    if not os.path.isfile(src):
        raise RuntimeError("Xray binary was not found inside the downloaded archive")

    dst = os.path.abspath(binary_name)
    if os.path.exists(dst):
        os.remove(dst)
    shutil.move(src, dst)
    os.chmod(dst, 0o755)
    shutil.rmtree(extract_dir, ignore_errors=True)
    print(f"[+] Xray {version} installed at {dst}")


if __name__ == "__main__":
    install_xray()
