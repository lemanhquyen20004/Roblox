#!/usr/bin/env bash
set -Eeuo pipefail

SERVICE_NAME="xray-vps-direct"
PANEL_SERVICE="xray-vps-panel"
GUARD_SERVICE="xray-vps-guard"
SERVICE_FILE="/etc/systemd/system/${SERVICE_NAME}.service"
PANEL_SERVICE_FILE="/etc/systemd/system/${PANEL_SERVICE}.service"
GUARD_SERVICE_FILE="/etc/systemd/system/${GUARD_SERVICE}.service"
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
INSTALL_DIR="/opt/xray-vps-direct"
VENV="${INSTALL_DIR}/venv"
NGINX_PANEL="/etc/nginx/conf.d/xray-vps-panel.conf"

ok()   { printf '\033[1;32m[+]\033[0m %s\n' "$*"; }
info() { printf '\033[1;34m[*]\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33m[!]\033[0m %s\n' "$*"; }
die()  { printf '\033[1;31m[x]\033[0m %s\n' "$*" >&2; exit 1; }

[ "$(id -u)" -eq 0 ] || die "Hãy chạy bằng root: sudo bash install.sh"
command -v apt-get >/dev/null 2>&1 || die "Bản tự cài hiện hỗ trợ Ubuntu/Debian dùng apt."

printf '\n=== XRAY VLESS DIRECT VPS + WEB PANEL ===\n\n'
read -r -p "Domain đã trỏ về VPS (vd: vpn.example.com): " DOMAIN
DOMAIN="${DOMAIN#http://}"; DOMAIN="${DOMAIN#https://}"; DOMAIN="${DOMAIN%%/*}"; DOMAIN="${DOMAIN%.}"
[ -n "$DOMAIN" ] || die "Domain không được để trống."
[[ "$DOMAIN" =~ ^([A-Za-z0-9-]+\.)+[A-Za-z]{2,63}$ ]] || die "Domain không hợp lệ: $DOMAIN"

read -r -p "Email Let's Encrypt (Enter để bỏ qua): " LE_EMAIL
read -r -p "Cổng xHTTP [8443]: " XHTTP_PORT
XHTTP_PORT="${XHTTP_PORT:-8443}"
[[ "$XHTTP_PORT" =~ ^[0-9]+$ ]] || die "Cổng xHTTP phải là số."
(( XHTTP_PORT >= 1 && XHTTP_PORT <= 65535 )) || die "Cổng xHTTP không hợp lệ."
[ "$XHTTP_PORT" != "443" ] || die "xHTTP phải dùng cổng khác 443."
[ "$XHTTP_PORT" != "80" ] || die "Không dùng cổng 80 vì Certbot cần cổng này."
[ "$XHTTP_PORT" != "10085" ] || die "Cổng 10085 dành cho Xray API nội bộ."

read -r -p "Cổng HTTPS Web Panel [9443]: " PANEL_PORT
PANEL_PORT="${PANEL_PORT:-9443}"
[[ "$PANEL_PORT" =~ ^[0-9]+$ ]] || die "Cổng Panel phải là số."
(( PANEL_PORT >= 1 && PANEL_PORT <= 65535 )) || die "Cổng Panel không hợp lệ."
[ "$PANEL_PORT" != "80" ] && [ "$PANEL_PORT" != "443" ] && [ "$PANEL_PORT" != "$XHTTP_PORT" ] && [ "$PANEL_PORT" != "10085" ] || die "Cổng Panel phải khác 80/443/xHTTP/10085."

read -r -p "Tài khoản Web Panel [admin]: " PANEL_USER
PANEL_USER="${PANEL_USER:-admin}"
[[ "$PANEL_USER" =~ ^[A-Za-z0-9_.-]{3,32}$ ]] || die "Tên tài khoản panel không hợp lệ."
read -r -s -p "Mật khẩu Web Panel (Enter = tự tạo): " PANEL_PASSWORD; printf '\n'
if [ -n "$PANEL_PASSWORD" ] && [ ${#PANEL_PASSWORD} -lt 10 ]; then
  die "Mật khẩu Panel phải có ít nhất 10 ký tự, hoặc để trống để tự tạo."
fi
if [ -z "$PANEL_PASSWORD" ]; then
  PANEL_PASSWORD="$(openssl rand -base64 18 | tr -d '/+=' | head -c 18)"
  GENERATED_PANEL_PASSWORD=1
else
  GENERATED_PANEL_PASSWORD=0
fi

UUID="$(cat /proc/sys/kernel/random/uuid 2>/dev/null || true)"
[ -n "$UUID" ] || UUID="$(python3 - <<'PY'
import uuid
print(uuid.uuid4())
PY
)"
RAND="$(tr -dc 'a-f0-9' </dev/urandom | head -c 12 || true)"
[ ${#RAND} -eq 12 ] || RAND="$(date +%s)"
WS_PATH="/ws-${RAND}"
XHTTP_PATH="/xh-${RAND}"

# Refuse if ports are already occupied before touching services.
if command -v ss >/dev/null 2>&1; then
  for P in 80 443 "$XHTTP_PORT" "$PANEL_PORT" 10085; do
    if ss -ltn "( sport = :$P )" 2>/dev/null | tail -n +2 | grep -q .; then
      warn "Cổng $P đang có dịch vụ sử dụng:"
      ss -ltnp "( sport = :$P )" || true
      die "Hãy giải phóng cổng $P rồi chạy lại."
    fi
  done
fi

info "Cài gói hệ thống cần thiết..."
export DEBIAN_FRONTEND=noninteractive
apt-get update
apt-get install -y python3 python3-venv python3-pip ca-certificates curl unzip certbot openssl dnsutils

PUBLIC_IPV4="$(curl -4fsS --max-time 8 https://api.ipify.org 2>/dev/null || true)"
DNS_IPV4="$(dig +short A "$DOMAIN" 2>/dev/null | head -n1 || true)"
if [ -n "$PUBLIC_IPV4" ] && [ -n "$DNS_IPV4" ]; then
  if [ "$PUBLIC_IPV4" != "$DNS_IPV4" ]; then
    warn "A record hiện là $DNS_IPV4 nhưng IPv4 công khai VPS là $PUBLIC_IPV4."
    warn "Với chế độ direct, DNS nên trỏ thẳng VPS và không proxy qua CDN."
  else
    ok "DNS A record đang trỏ đúng IPv4 VPS: $PUBLIC_IPV4"
  fi
else
  warn "Không xác minh được DNS/public IPv4; Certbot sẽ kiểm tra khi xin chứng chỉ."
fi

# Open only when firewall is already active; never enable a new firewall automatically.
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q '^Status: active'; then
  info "UFW đang hoạt động, mở cổng 80/443/${XHTTP_PORT}/${PANEL_PORT}..."
  ufw allow 80/tcp >/dev/null
  ufw allow 443/tcp >/dev/null
  ufw allow "${XHTTP_PORT}/tcp" >/dev/null
  ufw allow "${PANEL_PORT}/tcp" >/dev/null
elif command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
  info "firewalld đang hoạt động, mở cổng cần thiết..."
  for P in 80 443 "$XHTTP_PORT" "$PANEL_PORT"; do firewall-cmd --permanent --add-port="${P}/tcp" >/dev/null; done
  firewall-cmd --reload >/dev/null
else
  info "Không phát hiện firewall đang hoạt động; không tự bật firewall mới."
fi

info "Xin chứng chỉ Let's Encrypt cho $DOMAIN..."
CERTBOT_ARGS=(certonly --standalone --non-interactive --agree-tos --preferred-challenges http -d "$DOMAIN")
if [ -n "$LE_EMAIL" ]; then CERTBOT_ARGS+=(--email "$LE_EMAIL" --no-eff-email); else CERTBOT_ARGS+=(--register-unsafely-without-email); fi
certbot "${CERTBOT_ARGS[@]}"

CERT="/etc/letsencrypt/live/${DOMAIN}/fullchain.pem"
KEY="/etc/letsencrypt/live/${DOMAIN}/privkey.pem"
[ -s "$CERT" ] || die "Không tìm thấy certificate: $CERT"
[ -s "$KEY" ] || die "Không tìm thấy private key: $KEY"

info "Cài source vào $INSTALL_DIR..."
mkdir -p "$INSTALL_DIR"
cp "$SELF_DIR/main.py" "$SELF_DIR/panel.py" "$SELF_DIR/quota_guard.py" "$SELF_DIR/download-xray.py" "$SELF_DIR/requirements.txt" "$INSTALL_DIR/"
python3 -m venv "$VENV"
"$VENV/bin/pip" install --upgrade pip >/dev/null
"$VENV/bin/pip" install -r "$INSTALL_DIR/requirements.txt" >/dev/null

cat > "$INSTALL_DIR/.env" <<ENV
DOMAIN=$DOMAIN
LISTEN=0.0.0.0
XRAY_UUID=$UUID
TLS_CERT=$CERT
TLS_KEY=$KEY
ENABLE_WS=true
WS_PORT=443
WS_PATH=$WS_PATH
ENABLE_XHTTP=true
XHTTP_PORT=$XHTTP_PORT
XHTTP_PATH=$XHTTP_PATH
XHTTP_MODE=auto
LOG_LEVEL=warning
XRAY_API_PORT=10085
DATA_LIMIT_GB=0
DEVICE_LIMIT=0
ENV
chmod 600 "$INSTALL_DIR/.env"

cat > "$INSTALL_DIR/usage_state.json" <<'JSON_STATE'
{
  "uplink": 0,
  "downlink": 0,
  "updated_at": 0,
  "online_ips": {},
  "first_seen": {},
  "blocked_ips": [],
  "quota_exceeded": false,
  "last_error": ""
}
JSON_STATE
chmod 600 "$INSTALL_DIR/usage_state.json"
touch "$INSTALL_DIR/usage_state.lock"
chmod 600 "$INSTALL_DIR/usage_state.lock"

PANEL_HASH="$(PANEL_PASSWORD="$PANEL_PASSWORD" "$VENV/bin/python" - <<'PY'
import os
from werkzeug.security import generate_password_hash
print(generate_password_hash(os.environ['PANEL_PASSWORD'], method='scrypt'))
PY
)"
PANEL_SECRET="$(openssl rand -hex 32)"
cat > "$INSTALL_DIR/panel.env" <<ENV
PANEL_ADMIN_USER=$PANEL_USER
PANEL_PASSWORD_HASH=$PANEL_HASH
PANEL_SECRET_KEY=$PANEL_SECRET
PANEL_HTTPS_PORT=$PANEL_PORT
ENV
chmod 600 "$INSTALL_DIR/panel.env"

cat > "$SERVICE_FILE" <<EOF_SERVICE
[Unit]
Description=Xray VLESS Direct VPS (WS + xHTTP)
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
ExecStart=$VENV/bin/python $INSTALL_DIR/main.py
Restart=always
RestartSec=3
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
EOF_SERVICE

cat > "$PANEL_SERVICE_FILE" <<EOF_PANEL
[Unit]
Description=Xray VPS Web Panel
After=network-online.target ${SERVICE_NAME}.service
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
Environment=PYTHONUNBUFFERED=1
ExecStart=$VENV/bin/gunicorn --workers 2 --bind 127.0.0.1:9090 --access-logfile - --error-logfile - panel:app
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF_PANEL

cat > "$GUARD_SERVICE_FILE" <<EOF_GUARD
[Unit]
Description=Xray VPS Data Quota and Device Guard
After=network-online.target ${SERVICE_NAME}.service
Wants=network-online.target

[Service]
Type=simple
User=root
WorkingDirectory=$INSTALL_DIR
Environment=PYTHONUNBUFFERED=1
ExecStart=$VENV/bin/python $INSTALL_DIR/quota_guard.py
Restart=always
RestartSec=3

[Install]
WantedBy=multi-user.target
EOF_GUARD

info "Cài Nginx cho HTTPS Web Panel..."
apt-get install -y nginx
# Disable the package's default :80 vhost on fresh Debian/Ubuntu installs so certbot standalone can renew later.
if [ -L /etc/nginx/sites-enabled/default ]; then rm -f /etc/nginx/sites-enabled/default; fi
cat > "$NGINX_PANEL" <<EOF_NGINX
server {
    listen ${PANEL_PORT} ssl http2;
    listen [::]:${PANEL_PORT} ssl http2;
    server_name ${DOMAIN};

    ssl_certificate ${CERT};
    ssl_certificate_key ${KEY};
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_session_cache shared:SSL:10m;
    ssl_session_timeout 10m;
    server_tokens off;

    add_header X-Frame-Options "DENY" always;
    add_header X-Content-Type-Options "nosniff" always;
    add_header Referrer-Policy "no-referrer" always;

    location / {
        proxy_pass http://127.0.0.1:9090;
        proxy_http_version 1.1;
        proxy_set_header Host \$host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;
        proxy_read_timeout 60s;
    }
}
EOF_NGINX
nginx -t

mkdir -p /etc/letsencrypt/renewal-hooks/deploy
cat > /etc/letsencrypt/renewal-hooks/deploy/xray-vps-direct.sh <<EOF_HOOK
#!/usr/bin/env bash
systemctl try-restart ${SERVICE_NAME}.service >/dev/null 2>&1 || true
systemctl try-reload nginx.service >/dev/null 2>&1 || systemctl try-restart nginx.service >/dev/null 2>&1 || true
EOF_HOOK
chmod 755 /etc/letsencrypt/renewal-hooks/deploy/xray-vps-direct.sh

systemctl daemon-reload
systemctl enable "$SERVICE_NAME.service" "$PANEL_SERVICE.service" "$GUARD_SERVICE.service" nginx.service >/dev/null
info "Khởi động Xray + Web Panel + Data/Device Guard..."
systemctl restart "$SERVICE_NAME.service"
sleep 2
systemctl restart "$GUARD_SERVICE.service"
systemctl restart "$PANEL_SERVICE.service"
systemctl restart nginx.service
sleep 3

for S in "$SERVICE_NAME.service" "$PANEL_SERVICE.service" "$GUARD_SERVICE.service" nginx.service; do
  if ! systemctl is-active --quiet "$S"; then
    systemctl --no-pager --full status "$S" || true
    journalctl -u "$S" -n 80 --no-pager || true
    die "$S chưa khởi động thành công."
  fi
done

for _ in $(seq 1 15); do [ -s "$INSTALL_DIR/vless-links.txt" ] && break; sleep 1; done

printf '\n============================================================\n'
ok "CÀI ĐẶT THÀNH CÔNG"
printf 'Domain      : %s\n' "$DOMAIN"
printf 'UUID        : %s\n' "$UUID"
printf 'WS          : 443  %s\n' "$WS_PATH"
printf 'xHTTP       : %s  %s\n' "$XHTTP_PORT" "$XHTTP_PATH"
printf 'Web Panel   : https://%s:%s\n' "$DOMAIN" "$PANEL_PORT"
printf 'Panel user  : %s\n' "$PANEL_USER"
printf 'Panel pass  : %s\n' "$PANEL_PASSWORD"
printf 'Config      : %s/.env\n' "$INSTALL_DIR"
printf 'Links       : %s/vless-links.txt\n' "$INSTALL_DIR"
printf 'Xray log    : journalctl -u %s -f\n' "$SERVICE_NAME"
printf 'Panel log   : journalctl -u %s -f\n' "$PANEL_SERVICE"
printf 'Guard log   : journalctl -u %s -f\n' "$GUARD_SERVICE"
printf '============================================================\n\n'
[ -s "$INSTALL_DIR/vless-links.txt" ] && cat "$INSTALL_DIR/vless-links.txt" || warn "Chưa thấy file link; xem log Xray."
if [ "$GENERATED_PANEL_PASSWORD" -eq 1 ]; then printf '\n'; warn "Mật khẩu panel ở trên được tạo tự động. Hãy lưu lại và đổi sau khi đăng nhập."; fi
printf '\n'
