#!/usr/bin/env python3
import json
import os
import platform
import signal
import subprocess
import sys
import time
import urllib.parse
import uuid
from pathlib import Path

from dotenv import load_dotenv

import importlib
xray_downloader = importlib.import_module("download-xray")

USER_EMAIL = "vps-user@local"
API_PORT_DEFAULT = 10085


def parse_bool(value: str, default=False) -> bool:
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


def parse_port(value: str, default: int) -> int:
    value = (value or "").strip()
    if not value:
        return default
    port = int(value)
    if not 1 <= port <= 65535:
        raise ValueError(f"Invalid port: {port}")
    return port


def normalize_path(value: str, default: str) -> str:
    value = (value or default).strip()
    return value if value.startswith("/") else "/" + value


def save_env_value(path: str, key: str, value: str) -> None:
    lines = []
    found = False
    if os.path.exists(path):
        with open(path, "r", encoding="utf-8") as f:
            lines = f.readlines()
    out = []
    for line in lines:
        if line.startswith(key + "="):
            out.append(f"{key}={value}\n")
            found = True
        else:
            out.append(line)
    if not found:
        if out and not out[-1].endswith("\n"):
            out[-1] += "\n"
        out.append(f"{key}={value}\n")
    with open(path, "w", encoding="utf-8") as f:
        f.writelines(out)


def build_inbound(tag: str, listen: str, port: int, user_uuid: str, cert: str, key: str,
                  transport: str, path: str, xhttp_mode: str):
    stream = {
        "network": "ws" if transport == "websocket" else "xhttp",
        "security": "tls",
        "tlsSettings": {
            "certificates": [{
                "certificateFile": cert,
                "keyFile": key,
            }]
        },
    }
    if transport == "websocket":
        stream["wsSettings"] = {"path": path}
    else:
        stream["xhttpSettings"] = {"path": path, "mode": xhttp_mode}

    return {
        "tag": tag,
        "listen": listen,
        "port": port,
        "protocol": "vless",
        "settings": {
            "clients": [{"id": user_uuid, "level": 0, "email": USER_EMAIL}],
            "decryption": "none",
        },
        "sniffing": {
            "enabled": True,
            "destOverride": ["http", "tls", "quic"],
            "routeOnly": True,
        },
        "streamSettings": stream,
    }


def make_link(domain: str, port: int, user_uuid: str, transport: str,
              path: str, remark: str, xhttp_mode: str) -> str:
    q = {
        "encryption": "none",
        "security": "tls",
        "sni": domain,
        "type": "ws" if transport == "websocket" else "xhttp",
        "path": path,
        "host": domain,
    }
    if transport == "xhttp":
        q["mode"] = xhttp_mode
        q["alpn"] = "h3,h2,http/1.1"
    query = urllib.parse.urlencode(q, quote_via=urllib.parse.quote)
    fragment = urllib.parse.quote(remark, safe="")
    return f"vless://{user_uuid}@{domain}:{port}?{query}#{fragment}"


def main():
    base_dir = os.path.abspath(os.path.dirname(__file__))
    os.chdir(base_dir)
    env_path = os.path.join(base_dir, ".env")
    if not os.path.exists(env_path):
        example = os.path.join(base_dir, ".env.example")
        if os.path.exists(example):
            Path(env_path).write_text(Path(example).read_text(encoding="utf-8"), encoding="utf-8")
        else:
            raise SystemExit("[!] .env and .env.example are missing")

    load_dotenv(env_path, override=True)
    domain = (os.getenv("DOMAIN") or "").strip()
    listen = (os.getenv("LISTEN") or "0.0.0.0").strip()
    cert = os.path.expanduser((os.getenv("TLS_CERT") or "").strip())
    key = os.path.expanduser((os.getenv("TLS_KEY") or "").strip())
    user_uuid = (os.getenv("XRAY_UUID") or "").strip()
    api_port = parse_port(os.getenv("XRAY_API_PORT"), API_PORT_DEFAULT)

    enable_ws = parse_bool(os.getenv("ENABLE_WS"), True)
    enable_xhttp = parse_bool(os.getenv("ENABLE_XHTTP"), True)
    ws_port = parse_port(os.getenv("WS_PORT"), 443)
    xhttp_port = parse_port(os.getenv("XHTTP_PORT"), 8443)
    ws_path = normalize_path(os.getenv("WS_PATH"), "/vless-ws")
    xhttp_path = normalize_path(os.getenv("XHTTP_PATH"), "/vless-xhttp")
    xhttp_mode = (os.getenv("XHTTP_MODE") or "auto").strip().lower()
    if xhttp_mode not in {"auto", "packet-up", "stream-up", "stream-one"}:
        raise SystemExit(f"[!] Invalid XHTTP_MODE: {xhttp_mode}")

    if not domain:
        raise SystemExit("[!] DOMAIN is empty")
    if not enable_ws and not enable_xhttp:
        raise SystemExit("[!] Both ENABLE_WS and ENABLE_XHTTP are disabled")
    if enable_ws and enable_xhttp and ws_port == xhttp_port:
        raise SystemExit("[!] WS and xHTTP must use different ports in direct TLS mode")
    if api_port in {ws_port if enable_ws else -1, xhttp_port if enable_xhttp else -1}:
        raise SystemExit("[!] XRAY_API_PORT must differ from public VLESS ports")
    if not cert or not os.path.isfile(cert):
        raise SystemExit(f"[!] TLS_CERT not found: {cert or '(empty)'}")
    if not key or not os.path.isfile(key):
        raise SystemExit(f"[!] TLS_KEY not found: {key or '(empty)'}")

    if not user_uuid:
        user_uuid = str(uuid.uuid4())
        save_env_value(env_path, "XRAY_UUID", user_uuid)
        print(f"[+] Generated XRAY_UUID: {user_uuid}")

    xray_bin = os.path.join(base_dir, "xray.exe" if platform.system().lower() == "windows" else "xray")
    if not os.path.exists(xray_bin):
        print("[*] Xray binary not found. Downloading latest release...")
        xray_downloader.install_xray()
    if not os.path.exists(xray_bin):
        raise SystemExit("[!] Xray installation failed")

    inbounds = []
    links = []
    if enable_ws:
        inbounds.append(build_inbound("vless-ws", listen, ws_port, user_uuid, cert, key, "websocket", ws_path, xhttp_mode))
        links.append(make_link(domain, ws_port, user_uuid, "websocket", ws_path, "VPS Direct WS", xhttp_mode))
    if enable_xhttp:
        inbounds.append(build_inbound("vless-xhttp", listen, xhttp_port, user_uuid, cert, key, "xhttp", xhttp_path, xhttp_mode))
        links.append(make_link(domain, xhttp_port, user_uuid, "xhttp", xhttp_path, "VPS Direct XHTTP", xhttp_mode))

    # Local-only API inbound. Stats are enabled per user so the guard can persist usage
    # and retrieve Xray's online IP map for device-limit enforcement.
    inbounds.append({
        "tag": "api-in",
        "listen": "127.0.0.1",
        "port": api_port,
        "protocol": "dokodemo-door",
        "settings": {"address": "127.0.0.1"},
    })

    routing_rules = [{
        "type": "field",
        "inboundTag": ["api-in"],
        "outboundTag": "api",
    }]

    quota_flag = Path(base_dir) / "quota.block"
    if quota_flag.exists():
        routing_rules.append({
            "type": "field",
            "user": [USER_EMAIL],
            "outboundTag": "block",
        })

    config = {
        "log": {"loglevel": (os.getenv("LOG_LEVEL") or "warning").strip()},
        "api": {
            "tag": "api",
            "services": ["StatsService", "RoutingService"],
        },
        "stats": {},
        "policy": {
            "levels": {
                "0": {
                    "statsUserUplink": True,
                    "statsUserDownlink": True,
                    "statsUserOnline": True,
                }
            },
            "system": {
                "statsInboundUplink": True,
                "statsInboundDownlink": True,
            },
        },
        "routing": {
            "domainStrategy": "AsIs",
            "rules": routing_rules,
        },
        "inbounds": inbounds,
        "outbounds": [
            {"tag": "direct", "protocol": "freedom", "settings": {"domainStrategy": "UseIPv4"}},
            {"tag": "block", "protocol": "blackhole"},
        ],
    }

    config_path = os.path.join(base_dir, "config.json")
    with open(config_path, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)

    links_path = os.path.join(base_dir, "vless-links.txt")
    with open(links_path, "w", encoding="utf-8") as f:
        f.write("\n".join(links) + "\n")

    print("\n" + "=" * 72)
    print("VLESS DIRECT VPS + USAGE/DEVICE STATS")
    print("=" * 72)
    print(f"Domain     : {domain}")
    print(f"Stats user : {USER_EMAIL}")
    print(f"API        : 127.0.0.1:{api_port}")
    print(f"Quota      : {'BLOCKED' if quota_flag.exists() else 'OPEN'}")
    for link in links:
        print(link)
    print("=" * 72 + "\n")

    test = subprocess.run([xray_bin, "run", "-test", "-c", config_path], text=True)
    if test.returncode != 0:
        raise SystemExit("[!] Xray config validation failed")

    proc = subprocess.Popen([xray_bin, "run", "-c", config_path])

    def stop_handler(_signum, _frame):
        if proc.poll() is None:
            proc.terminate()

    signal.signal(signal.SIGTERM, stop_handler)
    signal.signal(signal.SIGINT, stop_handler)

    try:
        while proc.poll() is None:
            time.sleep(1)
    finally:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
    sys.exit(proc.returncode or 0)


if __name__ == "__main__":
    main()
