#!/usr/bin/env python3
import json
import os
import re
import secrets
import subprocess
import time
import uuid as uuidlib
from functools import wraps
from pathlib import Path

from dotenv import dotenv_values
from flask import Flask, flash, redirect, render_template_string, request, session, url_for
from werkzeug.security import check_password_hash

BASE_DIR = Path(__file__).resolve().parent
XRAY_ENV = BASE_DIR / ".env"
PANEL_ENV = BASE_DIR / "panel.env"
STATE_PATH = BASE_DIR / "usage_state.json"
LOCK_PATH = BASE_DIR / "usage_state.lock"
QUOTA_FLAG = BASE_DIR / "quota.block"
SERVICE = "xray-vps-direct.service"
GUARD_SERVICE = "xray-vps-guard.service"
USER_EMAIL = "vps-user@local"

panel_cfg = dotenv_values(PANEL_ENV)
secret_key = panel_cfg.get("PANEL_SECRET_KEY") or secrets.token_hex(32)
ADMIN_USER = panel_cfg.get("PANEL_ADMIN_USER") or "admin"
ADMIN_HASH = panel_cfg.get("PANEL_PASSWORD_HASH") or ""

app = Flask(__name__)
app.secret_key = secret_key
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SECURE=True,
    SESSION_COOKIE_SAMESITE="Lax",
    PERMANENT_SESSION_LIFETIME=3600 * 12,
)


def run(cmd, timeout=15):
    try:
        p = subprocess.run(cmd, cwd=BASE_DIR, text=True, capture_output=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except Exception as exc:
        return 1, str(exc)


def csrf_token():
    token = session.get("csrf")
    if not token:
        token = secrets.token_urlsafe(32)
        session["csrf"] = token
    return token


app.jinja_env.globals["csrf_token"] = csrf_token


def csrf_ok():
    return secrets.compare_digest(request.form.get("csrf", ""), session.get("csrf", ""))


def login_required(fn):
    @wraps(fn)
    def wrapped(*args, **kwargs):
        if not session.get("authenticated"):
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapped


def load_xray_env():
    return {k: (v or "") for k, v in dotenv_values(XRAY_ENV).items()}


def save_xray_env(updates):
    existing = XRAY_ENV.read_text(encoding="utf-8").splitlines() if XRAY_ENV.exists() else []
    seen = set()
    out = []
    for line in existing:
        if "=" in line and not line.lstrip().startswith("#"):
            key = line.split("=", 1)[0].strip()
            if key in updates:
                out.append(f"{key}={updates[key]}")
                seen.add(key)
                continue
        out.append(line)
    for key, value in updates.items():
        if key not in seen:
            out.append(f"{key}={value}")
    tmp = XRAY_ENV.with_suffix(".env.tmp")
    tmp.write_text("\n".join(out).rstrip() + "\n", encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, XRAY_ENV)


def service_state(service=SERVICE):
    rc, out = run(["systemctl", "is-active", service], timeout=5)
    state = out.strip().splitlines()[0] if out.strip() else "unknown"
    return state


def service_enabled():
    rc, _ = run(["systemctl", "is-enabled", SERVICE], timeout=5)
    return rc == 0


def recent_logs(lines=100):
    rc, out = run(["journalctl", "-u", SERVICE, "-n", str(lines), "--no-pager", "-o", "short-iso"], timeout=8)
    return out[-30000:] if out else "Không có log."


def xray_version():
    binary = BASE_DIR / "xray"
    if not binary.exists():
        return "Chưa cài"
    rc, out = run([str(binary), "version"], timeout=5)
    if rc != 0:
        return "Không đọc được"
    return (out.splitlines() or ["Không rõ"])[0]


def uptime_text():
    try:
        seconds = int(float(Path("/proc/uptime").read_text().split()[0]))
        days, rem = divmod(seconds, 86400)
        hours, rem = divmod(rem, 3600)
        mins, _ = divmod(rem, 60)
        return f"{days}d {hours}h {mins}m"
    except Exception:
        return "N/A"


def links_text():
    try:
        return (BASE_DIR / "vless-links.txt").read_text(encoding="utf-8").strip()
    except Exception:
        return ""


def empty_usage():
    return {
        "uplink": 0, "downlink": 0, "updated_at": 0,
        "online_ips": {}, "first_seen": {}, "blocked_ips": [],
        "quota_exceeded": False, "last_error": "",
    }


def load_usage():
    try:
        obj = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        out = empty_usage()
        if isinstance(obj, dict):
            out.update(obj)
        return out
    except Exception:
        return empty_usage()


def save_usage(state):
    tmp = STATE_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, STATE_PATH)


def human_bytes(n):
    try:
        n = max(0, int(n))
    except Exception:
        n = 0
    units = ["B", "KiB", "MiB", "GiB", "TiB"]
    value = float(n)
    for unit in units:
        if value < 1024 or unit == units[-1]:
            return f"{value:.2f} {unit}" if unit != "B" else f"{int(value)} B"
        value /= 1024


def parse_limit(cfg):
    try:
        return max(0.0, float(cfg.get("DATA_LIMIT_GB", "0") or 0))
    except Exception:
        return 0.0


def validate_config(form):
    updates = {}
    domain = load_xray_env().get("DOMAIN", "")
    raw_uuid = form.get("XRAY_UUID", "").strip()
    try:
        updates["XRAY_UUID"] = str(uuidlib.UUID(raw_uuid))
    except Exception:
        raise ValueError("UUID không hợp lệ.")

    ws_on = form.get("ENABLE_WS") == "on"
    xh_on = form.get("ENABLE_XHTTP") == "on"
    if not ws_on and not xh_on:
        raise ValueError("Phải bật ít nhất WS hoặc xHTTP.")

    def port(name):
        try:
            p = int(form.get(name, ""))
        except Exception:
            raise ValueError(f"{name} phải là số.")
        if p < 1 or p > 65535:
            raise ValueError(f"{name} ngoài phạm vi 1-65535.")
        return p

    ws_port = port("WS_PORT")
    xh_port = port("XHTTP_PORT")
    if ws_on and xh_on and ws_port == xh_port:
        raise ValueError("WS và xHTTP phải dùng hai cổng khác nhau ở chế độ TLS trực tiếp.")

    path_re = re.compile(r"^/[A-Za-z0-9._~!$&'()*+,;=:@%/-]{1,127}$")
    ws_path = form.get("WS_PATH", "").strip()
    xh_path = form.get("XHTTP_PATH", "").strip()
    if not path_re.match(ws_path):
        raise ValueError("WS path không hợp lệ.")
    if not path_re.match(xh_path):
        raise ValueError("xHTTP path không hợp lệ.")

    mode = form.get("XHTTP_MODE", "auto").strip()
    if mode not in {"auto", "packet-up", "stream-up", "stream-one"}:
        raise ValueError("xHTTP mode không hợp lệ.")
    level = form.get("LOG_LEVEL", "warning").strip().lower()
    if level not in {"debug", "info", "warning", "error", "none"}:
        raise ValueError("Log level không hợp lệ.")

    updates.update({
        "DOMAIN": domain,
        "ENABLE_WS": "true" if ws_on else "false",
        "WS_PORT": str(ws_port),
        "WS_PATH": ws_path,
        "ENABLE_XHTTP": "true" if xh_on else "false",
        "XHTTP_PORT": str(xh_port),
        "XHTTP_PATH": xh_path,
        "XHTTP_MODE": mode,
        "LOG_LEVEL": level,
    })
    return updates


BASE_HTML = r'''<!doctype html>
<html lang="vi"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#070b14"><meta name="color-scheme" content="dark">
<title>{{ title }} · Xray Control</title>
<style>
:root{--bg:#070b14;--panel:rgba(14,21,36,.78);--line:rgba(148,163,184,.14);--line2:rgba(148,163,184,.22);--text:#f7f9fc;--muted:#8f9bb3;--blue:#5b8cff;--cyan:#37d8ff;--violet:#9b7cff;--green:#43e39f;--red:#ff6680;--amber:#ffca6a;--sidebar:246px}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;min-height:100vh;background:radial-gradient(900px 520px at 88% -10%,rgba(91,140,255,.16),transparent 60%),radial-gradient(780px 520px at -8% 28%,rgba(155,124,255,.12),transparent 58%),linear-gradient(180deg,#080d18 0%,#060912 100%);color:var(--text);font:14px/1.5 Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;letter-spacing:-.01em}
body:before{content:"";position:fixed;inset:0;pointer-events:none;background-image:linear-gradient(rgba(255,255,255,.018) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.018) 1px,transparent 1px);background-size:44px 44px;mask-image:linear-gradient(to bottom,black,transparent 70%);z-index:-1}a{color:inherit;text-decoration:none}.app{min-height:100vh}
.sidebar{position:fixed;left:0;top:0;bottom:0;width:var(--sidebar);padding:22px 16px;border-right:1px solid var(--line);background:rgba(7,11,20,.72);backdrop-filter:blur(22px);z-index:30;display:flex;flex-direction:column}.logo{display:flex;align-items:center;gap:11px;padding:7px 8px 21px}.logo-mark{width:39px;height:39px;border-radius:13px;display:grid;place-items:center;background:linear-gradient(135deg,var(--blue),var(--violet));box-shadow:0 10px 30px rgba(91,140,255,.24)}.logo-mark svg{width:22px;height:22px}.logo-text{font-size:16px;font-weight:850;letter-spacing:-.03em}.logo-sub{display:block;color:var(--muted);font-size:10px;font-weight:650;letter-spacing:.06em;text-transform:uppercase;margin-top:1px}.nav-label{padding:13px 11px 7px;color:#66738d;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.13em}.nav a{display:flex;align-items:center;gap:11px;padding:10px 11px;margin:3px 0;border-radius:12px;color:#9aa6bc;font-weight:650;transition:.18s ease}.nav a svg{width:18px;height:18px;opacity:.85}.nav a:hover,.nav a.active{background:linear-gradient(90deg,rgba(91,140,255,.14),rgba(91,140,255,.05));color:#eef4ff}.nav a.active{box-shadow:inset 0 0 0 1px rgba(91,140,255,.14)}.side-foot{margin-top:auto}.server-mini{padding:12px;border:1px solid var(--line);border-radius:15px;background:rgba(255,255,255,.025)}.server-mini .row{display:flex;justify-content:space-between;gap:8px;margin-top:7px;font-size:11px}.server-mini .row span:first-child{color:var(--muted)}.main{margin-left:var(--sidebar);min-height:100vh}.content{max-width:1500px;margin:0 auto;padding:25px 30px 42px}
.topbar{display:flex;align-items:center;justify-content:space-between;gap:16px;margin-bottom:22px}.headline h1{font-size:23px;line-height:1.1;margin:0 0 5px;font-weight:860;letter-spacing:-.045em}.headline p{margin:0;color:var(--muted);font-size:12px}.top-actions{display:flex;align-items:center;gap:9px}.status-chip{display:inline-flex;align-items:center;gap:8px;border:1px solid rgba(67,227,159,.22);background:rgba(67,227,159,.07);padding:8px 11px;border-radius:999px;color:#b9f7da;font-size:11px;font-weight:750}.status-chip.off{border-color:rgba(255,102,128,.22);background:rgba(255,102,128,.07);color:#ffb8c4}.pulse{width:7px;height:7px;border-radius:50%;background:var(--green);box-shadow:0 0 0 5px rgba(67,227,159,.08)}.off .pulse{background:var(--red);box-shadow:0 0 0 5px rgba(255,102,128,.07)}
.grid{display:grid;grid-template-columns:repeat(12,minmax(0,1fr));gap:14px}.card{position:relative;border:1px solid var(--line);background:linear-gradient(160deg,rgba(18,27,46,.78),rgba(10,16,29,.82));border-radius:22px;box-shadow:0 15px 40px rgba(0,0,0,.13);overflow:hidden}.card:before{content:"";position:absolute;inset:0;pointer-events:none;background:linear-gradient(135deg,rgba(255,255,255,.035),transparent 34%)}.pad{padding:18px}.span12{grid-column:span 12}.span8{grid-column:span 8}.span7{grid-column:span 7}.span6{grid-column:span 6}.span5{grid-column:span 5}.span4{grid-column:span 4}.span3{grid-column:span 3}.section-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:16px}.section-title{font-size:14px;font-weight:800;letter-spacing:-.025em}.section-sub{color:var(--muted);font-size:11px;margin-top:3px}.iconbox{width:36px;height:36px;border-radius:12px;display:grid;place-items:center;background:rgba(91,140,255,.09);border:1px solid rgba(91,140,255,.13);color:#9cbaff}.iconbox svg{width:18px;height:18px}
.kpi{padding:17px}.kpi-label{display:flex;justify-content:space-between;align-items:center;color:var(--muted);font-size:11px;font-weight:650}.kpi-value{font-size:25px;font-weight:870;letter-spacing:-.045em;margin:8px 0 4px}.kpi-note{font-size:10px;color:#6f7d95}.mini-dot{width:7px;height:7px;border-radius:50%;background:var(--green);box-shadow:0 0 10px rgba(67,227,159,.6)}.mini-dot.bad{background:var(--red);box-shadow:0 0 10px rgba(255,102,128,.4)}
.hero{grid-column:span 7;min-height:285px}.quota-card{grid-column:span 5;min-height:285px}.hero-grid{display:grid;grid-template-columns:1.2fr .8fr;gap:18px;align-items:end;height:100%}.hero-number{font-size:42px;font-weight:900;letter-spacing:-.06em;line-height:1;margin:16px 0 7px}.hero-caption{color:var(--muted);font-size:11px}.splitbar{height:10px;border-radius:999px;overflow:hidden;background:#0a1020;border:1px solid var(--line);display:flex;margin:20px 0 11px}.splitbar .up{background:linear-gradient(90deg,var(--blue),#78a4ff)}.splitbar .down{background:linear-gradient(90deg,var(--violet),#b392ff)}.legend{display:flex;gap:15px;flex-wrap:wrap}.legend span{display:inline-flex;align-items:center;gap:7px;color:var(--muted);font-size:10px}.legend i{width:7px;height:7px;border-radius:50%;display:inline-block}.traffic-list{display:grid;gap:9px}.traffic-item{padding:11px 12px;border:1px solid var(--line);border-radius:14px;background:rgba(5,10,19,.38)}.traffic-item small{display:block;color:var(--muted);font-size:9px;text-transform:uppercase;letter-spacing:.09em;font-weight:800}.traffic-item strong{display:block;margin-top:3px;font-size:14px}
.chartbars{height:92px;display:flex;align-items:flex-end;gap:6px;margin:16px 0 2px;padding:0 2px;border-bottom:1px solid var(--line)}.chartbars i{flex:1;height:var(--h);min-height:7px;border-radius:5px 5px 2px 2px;background:linear-gradient(180deg,rgba(91,140,255,.78),rgba(155,124,255,.22));box-shadow:0 0 18px rgba(91,140,255,.05)}.hero-grid>div:first-child{display:flex;flex-direction:column;justify-content:flex-end}.ring-wrap{display:flex;align-items:center;justify-content:center;min-height:172px}.ring{--p:0;width:156px;height:156px;border-radius:50%;display:grid;place-items:center;background:conic-gradient(var(--cyan) calc(var(--p)*1%),rgba(255,255,255,.055) 0);position:relative;box-shadow:inset 0 0 30px rgba(55,216,255,.04),0 0 38px rgba(55,216,255,.04)}.ring:after{content:"";position:absolute;width:124px;height:124px;border-radius:50%;background:linear-gradient(145deg,#0d1627,#09101d);border:1px solid var(--line)}.ring-core{position:relative;z-index:2;text-align:center}.ring-core strong{font-size:27px;display:block;letter-spacing:-.05em}.ring-core span{font-size:9px;color:var(--muted);text-transform:uppercase;letter-spacing:.09em}.quota-meta{display:grid;grid-template-columns:1fr 1fr;gap:8px}.quota-meta div{padding:9px 10px;border-radius:12px;border:1px solid var(--line);background:rgba(255,255,255,.022)}.quota-meta small{color:var(--muted);font-size:9px;display:block}.quota-meta strong{font-size:12px}.state-banner{display:flex;align-items:center;gap:10px;padding:10px 12px;border:1px solid rgba(67,227,159,.17);background:rgba(67,227,159,.055);border-radius:13px;margin-top:10px;color:#b9f7da;font-size:11px;font-weight:700}.state-banner.blocked{border-color:rgba(255,102,128,.2);background:rgba(255,102,128,.06);color:#ffc2cc}
.btn{appearance:none;border:1px solid var(--line2);background:rgba(255,255,255,.045);color:#dfe7f4;padding:9px 12px;border-radius:11px;font:inherit;font-size:11px;font-weight:750;cursor:pointer;transition:.17s ease;display:inline-flex;align-items:center;justify-content:center;gap:7px;white-space:nowrap}.btn svg{width:15px;height:15px}.btn:hover{transform:translateY(-1px);border-color:rgba(148,163,184,.33);background:rgba(255,255,255,.07)}.btn.primary{background:linear-gradient(135deg,#4b7ff0,#706cff);border-color:rgba(130,150,255,.5);color:white;box-shadow:0 9px 24px rgba(75,127,240,.18)}.btn.danger{background:rgba(255,102,128,.08);border-color:rgba(255,102,128,.2);color:#ffadba}.btn.success{background:rgba(67,227,159,.08);border-color:rgba(67,227,159,.18);color:#b9f7da}.btn.ghost{background:transparent}.actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.field{margin:11px 0}.field label,.label{display:block;color:#8d9ab1;font-size:10px;font-weight:700;margin:0 0 6px}.field input,.field select{width:100%;height:39px;background:rgba(5,10,20,.62);border:1px solid var(--line2);border-radius:11px;padding:0 11px;color:var(--text);outline:none;font:inherit;font-size:12px;transition:.16s}.field input:focus,.field select:focus{border-color:rgba(91,140,255,.55);box-shadow:0 0 0 3px rgba(91,140,255,.08)}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:0 11px}.toggle{display:flex;align-items:center;gap:9px;font-size:11px;font-weight:700;color:#cdd6e4;margin:4px 0 8px}.toggle input{appearance:none;width:34px;height:19px;border-radius:999px;background:#202a3d;border:1px solid var(--line2);position:relative;cursor:pointer;transition:.18s}.toggle input:before{content:"";position:absolute;width:13px;height:13px;border-radius:50%;left:2px;top:2px;background:#8b97aa;transition:.18s}.toggle input:checked{background:rgba(91,140,255,.55);border-color:rgba(91,140,255,.6)}.toggle input:checked:before{left:17px;background:white}.divider{height:1px;background:var(--line);margin:15px 0}
.pill{display:inline-flex;align-items:center;gap:6px;padding:5px 8px;border-radius:999px;border:1px solid var(--line);background:rgba(255,255,255,.025);font-size:9px;font-weight:800;color:#aeb9cb;text-transform:uppercase;letter-spacing:.04em}.pill.ok{color:#aaf2d0;border-color:rgba(67,227,159,.18);background:rgba(67,227,159,.06)}.pill.bad{color:#ffb4c0;border-color:rgba(255,102,128,.2);background:rgba(255,102,128,.06)}.device-list{display:grid;gap:7px}.device{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:11px;border:1px solid var(--line);border-radius:14px;background:rgba(5,10,20,.36)}.device-left{display:flex;align-items:center;gap:10px;min-width:0}.device-icon{width:34px;height:34px;border-radius:11px;display:grid;place-items:center;background:rgba(91,140,255,.08);border:1px solid rgba(91,140,255,.12);color:#8eafff;flex:none}.device-icon svg{width:17px;height:17px}.device-ip{font:650 11px/1.3 ui-monospace,SFMono-Regular,Consolas,monospace;overflow:hidden;text-overflow:ellipsis}.device-time{color:var(--muted);font-size:9px;margin-top:3px}.empty{padding:30px 12px;text-align:center;color:var(--muted);border:1px dashed var(--line2);border-radius:14px}.empty svg{width:30px;height:30px;opacity:.45;margin-bottom:7px}
.limit-summary{display:grid;grid-template-columns:1fr 1fr;gap:9px;margin-bottom:10px}.summary-box{padding:12px;border:1px solid var(--line);border-radius:14px;background:rgba(5,10,20,.34)}.summary-box small{color:var(--muted);font-size:9px;display:block}.summary-box strong{font-size:15px;display:block;margin-top:3px}.progress{height:7px;border-radius:999px;background:#080d17;overflow:hidden;border:1px solid var(--line);margin:8px 0 3px}.progress i{height:100%;display:block;border-radius:inherit;background:linear-gradient(90deg,var(--blue),var(--cyan));box-shadow:0 0 14px rgba(55,216,255,.25)}.links{font:11px/1.55 ui-monospace,SFMono-Regular,Consolas,monospace;word-break:break-all;background:#070b13;border:1px solid var(--line);border-radius:13px;padding:12px;color:#bdc9da;max-height:160px;overflow:auto;transition:.2s}.links.blurred{filter:blur(5px);user-select:none}.log{font:10px/1.65 ui-monospace,SFMono-Regular,Consolas,monospace;white-space:pre-wrap;word-break:break-word;background:#060a11;border:1px solid var(--line);border-radius:13px;padding:13px;color:#aebbd0;max-height:330px;overflow:auto}.flash-stack{display:grid;gap:8px;margin-bottom:14px}.flash{padding:11px 13px;border-radius:13px;border:1px solid var(--line);font-size:11px;font-weight:650;backdrop-filter:blur(10px)}.flash.ok{border-color:rgba(67,227,159,.2);background:rgba(67,227,159,.07);color:#b9f7da}.flash.error{border-color:rgba(255,102,128,.2);background:rgba(255,102,128,.07);color:#ffc1cc}.warning{padding:11px 12px;border:1px solid rgba(255,202,106,.2);background:rgba(255,202,106,.055);color:#ffe1a8;border-radius:13px;font-size:10px}.foot{text-align:center;color:#56627a;font-size:9px;padding:18px 0 0}.mobile-head{display:none}.toast{position:fixed;right:24px;bottom:24px;z-index:80;padding:10px 13px;border:1px solid rgba(67,227,159,.2);background:rgba(10,23,21,.92);color:#b9f7da;border-radius:12px;font-size:11px;font-weight:700;opacity:0;transform:translateY(8px);pointer-events:none;transition:.2s;backdrop-filter:blur(16px)}.toast.show{opacity:1;transform:translateY(0)}
.mobile-nav{display:none}.login-shell{min-height:100vh;display:grid;place-items:center;padding:22px;position:relative;overflow:hidden}.login-shell:before,.login-shell:after{content:"";position:absolute;width:420px;height:420px;border-radius:50%;filter:blur(80px);opacity:.16;pointer-events:none}.login-shell:before{background:var(--blue);left:-130px;top:-120px}.login-shell:after{background:var(--violet);right:-140px;bottom:-130px}.login-card{width:min(100%,410px);padding:26px;border:1px solid var(--line2);border-radius:26px;background:rgba(10,16,29,.8);backdrop-filter:blur(24px);box-shadow:0 24px 70px rgba(0,0,0,.35);position:relative;z-index:1}.login-brand{text-align:center;margin-bottom:22px}.login-logo{width:48px;height:48px;margin:0 auto 12px;border-radius:16px;display:grid;place-items:center;background:linear-gradient(135deg,var(--blue),var(--violet));box-shadow:0 14px 38px rgba(91,140,255,.22)}.login-logo svg{width:26px;height:26px}.login-brand h1{margin:0;font-size:20px;font-weight:880;letter-spacing:-.04em}.login-brand p{margin:5px 0 0;color:var(--muted);font-size:10px}.login-badge{display:inline-flex;align-items:center;gap:6px;margin-top:10px;padding:5px 8px;border-radius:999px;background:rgba(67,227,159,.06);border:1px solid rgba(67,227,159,.15);color:#aef4d1;font-size:9px;font-weight:800}.login-card .btn{width:100%;height:41px;margin-top:5px}.secure-note{text-align:center;color:#63718a;font-size:9px;margin-top:13px}
@media(max-width:1150px){.span3{grid-column:span 6}.hero,.quota-card{grid-column:span 12}.hero{min-height:auto}.span7,.span5{grid-column:span 12}}
@media(max-width:900px){:root{--sidebar:0px}.sidebar{display:none}.main{margin-left:0}.content{padding:15px 13px 92px}.mobile-nav{position:fixed;display:flex;left:10px;right:10px;bottom:10px;z-index:70;justify-content:space-around;gap:4px;padding:7px;border:1px solid rgba(148,163,184,.18);border-radius:18px;background:rgba(8,13,24,.88);backdrop-filter:blur(22px);box-shadow:0 16px 45px rgba(0,0,0,.4)}.mobile-nav a{flex:1;text-align:center;padding:8px 3px;border-radius:12px;color:#8e9ab0;font-size:9px;font-weight:750}.mobile-nav a:first-child{background:rgba(91,140,255,.11);color:#dbe7ff}.mobile-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:16px}.topbar{margin-bottom:14px}.topbar .headline{display:none}.top-actions .status-chip{display:none}.grid{gap:10px}.span6,.span8,.span4{grid-column:span 12}.hero-grid{grid-template-columns:1fr}.hero-number{font-size:35px}.ring-wrap{min-height:155px}.card{border-radius:18px}.pad{padding:15px}.kpi{padding:14px}.top-actions{width:100%;justify-content:flex-end}.mobile-brand{display:flex;align-items:center;gap:9px;font-weight:850}.mobile-brand .logo-mark{width:34px;height:34px;border-radius:11px}.mobile-brand .logo-mark svg{width:19px;height:19px}}
@media(max-width:560px){.span3{grid-column:span 12}.form-grid,.limit-summary,.quota-meta{grid-template-columns:1fr}.hero-grid{gap:8px}.hero-number{font-size:31px}.kpi-value{font-size:22px}.actions .btn{flex:1}.device{align-items:flex-start}.content{padding-bottom:24px}.top-actions .btn span{display:none}.login-card{padding:21px}.ring{width:145px;height:145px}.ring:after{width:115px;height:115px}}
</style></head><body>{{body|safe}}<div id="toast" class="toast">Đã sao chép</div>
<script>
function copyLinks(){const el=document.getElementById('links');if(!el)return;navigator.clipboard.writeText(el.innerText).then(()=>showToast('Đã sao chép link VLESS')).catch(()=>showToast('Không thể sao chép'));}
function showToast(t){const x=document.getElementById('toast');x.textContent=t;x.classList.add('show');clearTimeout(window.__tt);window.__tt=setTimeout(()=>x.classList.remove('show'),1800)}
function toggleSecret(){const el=document.getElementById('links');if(!el)return;el.classList.toggle('blurred');const b=document.getElementById('secretBtn');if(b)b.textContent=el.classList.contains('blurred')?'Hiện':'Ẩn'}
</script></body></html>'''

LOGIN_BODY = r'''<div class="login-shell"><div class="login-card"><div class="login-brand"><div class="login-logo"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M12 2 4 6v5c0 5.5 3.4 9 8 11 4.6-2 8-5.5 8-11V6l-8-4Z"/><path d="m9 12 2 2 4-4"/></svg></div><h1>Xray Control</h1><p>Secure VPS management console</p><span class="login-badge"><span class="pulse"></span>HTTPS protected</span></div>{% with msgs=get_flashed_messages(with_categories=true) %}<div class="flash-stack">{% for c,m in msgs %}<div class="flash {{c}}">{{m}}</div>{% endfor %}</div>{% endwith %}<form method="post"><input type="hidden" name="csrf" value="{{csrf_token()}}"><div class="field"><label>TÀI KHOẢN</label><input name="username" autocomplete="username" placeholder="admin" required></div><div class="field"><label>MẬT KHẨU</label><input type="password" name="password" autocomplete="current-password" placeholder="••••••••••" required></div><button class="btn primary">Đăng nhập Panel</button></form><div class="secure-note">Phiên đăng nhập được bảo vệ bằng Secure Cookie + CSRF</div></div></div>'''

DASH_BODY = r'''
<div class="app"><aside class="sidebar"><div class="logo"><div class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 12.5 9.5 17 19 7.5"/><path d="M12 2 4 6v5c0 5.5 3.4 9 8 11 4.6-2 8-5.5 8-11V6l-8-4Z"/></svg></div><div class="logo-text">Xray Control<span class="logo-sub">VPS Dashboard</span></div></div><div class="nav-label">Workspace</div><nav class="nav"><a class="active" href="#overview">▦ Tổng quan</a><a href="#devices">▣ Thiết bị</a><a href="#connection">⇄ Kết nối</a><a href="#settings">⚙ Cấu hình</a><a href="#logs">☷ Nhật ký</a></nav><div class="side-foot"><div class="server-mini"><span class="pill {{'ok' if state=='active' else 'bad'}}">{{state}}</span><div class="row"><span>Domain</span><b>{{cfg.DOMAIN}}</b></div><div class="row"><span>Uptime</span><b>{{uptime}}</b></div></div></div></aside>
<main class="main"><div class="content"><div class="mobile-head"><div class="mobile-brand"><div class="logo-mark"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M5 12.5 9.5 17 19 7.5"/><path d="M12 2 4 6v5c0 5.5 3.4 9 8 11 4.6-2 8-5.5 8-11V6l-8-4Z"/></svg></div>Xray Control</div><span class="pill {{'ok' if state=='active' else 'bad'}}">{{state}}</span></div>
<div class="topbar"><div class="headline"><h1>Xin chào, Admin</h1><p>{{cfg.DOMAIN}} · bảng điều khiển Xray trực tiếp</p></div><div class="top-actions"><span class="status-chip {{'off' if state!='active' else ''}}"><span class="pulse"></span>{{'Hệ thống hoạt động' if state=='active' else 'Xray đang dừng'}}</span><a class="btn ghost" href="/">↻ <span>Làm mới</span></a><form method="post" action="{{url_for('logout')}}"><input type="hidden" name="csrf" value="{{csrf_token()}}"><button class="btn ghost">↪ <span>Đăng xuất</span></button></form></div></div>
{% with msgs=get_flashed_messages(with_categories=true) %}<div class="flash-stack">{% for c,m in msgs %}<div class="flash {{c}}">{{m}}</div>{% endfor %}</div>{% endwith %}
<section id="overview" class="grid">
<div class="card span3 kpi"><div class="kpi-label"><span>Xray Core</span><span class="mini-dot {{'bad' if state!='active' else ''}}"></span></div><div class="kpi-value">{{state|capitalize}}</div><div class="kpi-note">Guard {{guard_state}} · autostart {{'on' if enabled else 'off'}}</div></div>
<div class="card span3 kpi"><div class="kpi-label"><span>Data đã dùng</span><span class="pill">Total</span></div><div class="kpi-value">{{used_total}}</div><div class="kpi-note">Tổng upload + download</div></div>
<div class="card span3 kpi"><div class="kpi-label"><span>Thiết bị online</span><span class="pill {{'bad' if device_limit and online_count>device_limit else 'ok'}}">Live</span></div><div class="kpi-value">{{online_count}}{{(' / ' ~ device_limit) if device_limit else ''}}</div><div class="kpi-note">Theo public source IP</div></div>
<div class="card span3 kpi"><div class="kpi-label"><span>Giới hạn Data</span><span class="pill">Quota</span></div><div class="kpi-value">{{limit_text}}</div><div class="kpi-note">{{('%.1f'|format(limit_percent) ~ '% đã dùng') if limit_percent is not none else 'Không giới hạn'}}</div></div>
<div class="card hero pad"><div class="section-head"><div><div class="section-title">Traffic overview</div><div class="section-sub">Lưu lượng của UUID hiện tại trên WS + xHTTP</div></div><div class="iconbox">↕</div></div><div class="hero-grid"><div><div class="hero-number">{{used_total}}</div><div class="hero-caption">Tổng lưu lượng đã ghi nhận bền vững</div><div class="chartbars" aria-hidden="true"><i style="--h:28%"></i><i style="--h:42%"></i><i style="--h:36%"></i><i style="--h:61%"></i><i style="--h:47%"></i><i style="--h:73%"></i><i style="--h:56%"></i><i style="--h:82%"></i><i style="--h:65%"></i><i style="--h:90%"></i><i style="--h:72%"></i><i style="--h:96%"></i></div><div class="splitbar"><span class="up" style="width:{{up_percent}}%"></span><span class="down" style="width:{{down_percent}}%"></span></div><div class="legend"><span><i style="background:var(--blue)"></i>Upload {{used_up}}</span><span><i style="background:var(--violet)"></i>Download {{used_down}}</span></div></div><div class="traffic-list"><div class="traffic-item"><small>Upload</small><strong>{{used_up}}</strong></div><div class="traffic-item"><small>Download</small><strong>{{used_down}}</strong></div><div class="traffic-item"><small>Updated</small><strong>{{updated_text}}</strong></div></div></div></div>
<div class="card quota-card pad"><div class="section-head"><div><div class="section-title">Data quota</div><div class="section-sub">Theo dõi mức sử dụng so với giới hạn</div></div><span class="pill {{'bad' if usage.quota_exceeded else 'ok'}}">{{'Blocked' if usage.quota_exceeded else 'Allowed'}}</span></div><div class="ring-wrap"><div class="ring" style="--p:{{quota_ring}}"><div class="ring-core"><strong>{{('%.0f'|format(limit_percent)) if limit_percent is not none else '∞'}}</strong><span>{{'percent used' if limit_percent is not none else 'unlimited'}}</span></div></div></div><div class="quota-meta"><div><small>Đã dùng</small><strong>{{used_total}}</strong></div><div><small>Giới hạn</small><strong>{{limit_text}}</strong></div></div><div class="state-banner {{'blocked' if usage.quota_exceeded else ''}}"><span class="mini-dot {{'bad' if usage.quota_exceeded else ''}}"></span>{{'Đã khóa kết nối vì hết quota' if usage.quota_exceeded else 'Kết nối đang được cho phép'}}</div></div>
<div id="devices" class="card span7 pad"><div class="section-head"><div><div class="section-title">Thiết bị đang online</div><div class="section-sub">IP hoạt động gần đây mà Xray Stats ghi nhận</div></div><span class="pill">{{online_count}} online</span></div>{% if devices %}<div class="device-list">{% for d in devices %}<div class="device"><div class="device-left"><div class="device-icon">▣</div><div><div class="device-ip">{{d.ip}}</div><div class="device-time">Last seen · {{d.last_seen}}</div></div></div><span class="pill {{'bad' if d.blocked else 'ok'}}">{{'Blocked' if d.blocked else 'Allowed'}}</span></div>{% endfor %}</div>{% else %}<div class="empty">▣<div>Chưa có thiết bị online</div></div>{% endif %}<div class="section-sub" style="margin-top:10px">Nhiều máy chung NAT/public IP có thể được tính là một thiết bị.</div></div>
<div class="card span5 pad"><div class="section-head"><div><div class="section-title">Giới hạn sử dụng</div><div class="section-sub">Quota Data và số IP online tối đa</div></div><div class="iconbox">⌁</div></div><div class="limit-summary"><div class="summary-box"><small>Data limit</small><strong>{{limit_text}}</strong></div><div class="summary-box"><small>Device limit</small><strong>{{device_limit if device_limit else '∞'}}</strong></div></div>{% if limit_percent is not none %}<div class="section-sub">{{'%.1f'|format(limit_percent)}}% quota đã sử dụng</div><div class="progress"><i style="width:{{quota_ring}}%"></i></div>{% endif %}<form method="post" action="{{url_for('save_limits')}}"><input type="hidden" name="csrf" value="{{csrf_token()}}"><div class="form-grid"><div class="field"><label>DATA LIMIT (GB)</label><input type="number" min="0" step="0.1" name="DATA_LIMIT_GB" value="{{cfg.DATA_LIMIT_GB or '0'}}"></div><div class="field"><label>DEVICE / IP LIMIT</label><input type="number" min="0" max="1000" step="1" name="DEVICE_LIMIT" value="{{cfg.DEVICE_LIMIT or '0'}}"></div></div><button class="btn primary">Lưu giới hạn</button></form><div class="divider"></div><form method="post" action="{{url_for('reset_data')}}" onsubmit="return confirm('Reset toàn bộ Data đã dùng về 0?')"><input type="hidden" name="csrf" value="{{csrf_token()}}"><button class="btn danger">Reset Data về 0</button></form></div>
<div id="connection" class="card span6 pad"><div class="section-head"><div><div class="section-title">Thông tin kết nối</div><div class="section-sub">Link VLESS hiện tại</div></div><div class="actions"><span class="pill">WS {{cfg.WS_PORT}}</span><span class="pill">xHTTP {{cfg.XHTTP_PORT}}</span></div></div><div class="links blurred" id="links">{{links or 'Chưa có link VLESS.'}}</div><div class="actions" style="margin-top:10px"><button class="btn primary" type="button" onclick="copyLinks()">Copy link</button><button class="btn" type="button" id="secretBtn" onclick="toggleSecret()">Hiện</button></div></div>
<div class="card span6 pad"><div class="section-head"><div><div class="section-title">Điều khiển dịch vụ</div><div class="section-sub">Quản lý Xray Core và UUID</div></div><span class="pill {{'ok' if state=='active' else 'bad'}}">{{state}}</span></div><div class="actions">{% for a,label,cls in [('start','Start','success'),('restart','Restart',''),('stop','Stop','danger')] %}<form method="post" action="{{url_for('service_action',action=a)}}"><input type="hidden" name="csrf" value="{{csrf_token()}}"><button class="btn {{cls}}">{{label}}</button></form>{% endfor %}<form method="post" action="{{url_for('update_xray')}}"><input type="hidden" name="csrf" value="{{csrf_token()}}"><button class="btn">Update Core</button></form><form method="post" action="{{url_for('regen_uuid')}}" onsubmit="return confirm('Tạo UUID mới và reset bộ đếm Data?')"><input type="hidden" name="csrf" value="{{csrf_token()}}"><button class="btn">UUID mới</button></form></div><div class="divider"></div><div class="section-sub">{{version}}<br>VPS uptime {{uptime}} · Autostart {{'bật' if enabled else 'tắt'}}</div></div>
<div id="settings" class="card span7 pad"><div class="section-head"><div><div class="section-title">Cấu hình VLESS</div><div class="section-sub">Thay đổi sẽ restart Xray sau khi lưu</div></div><div class="iconbox">⚙</div></div><form method="post" action="{{url_for('save_config')}}"><input type="hidden" name="csrf" value="{{csrf_token()}}"><div class="field"><label>UUID</label><input name="XRAY_UUID" value="{{cfg.XRAY_UUID}}" required></div><div class="form-grid"><div><label class="toggle"><input type="checkbox" name="ENABLE_WS" {{'checked' if cfg.ENABLE_WS|lower=='true' else ''}}>WebSocket</label><div class="field"><label>WS PORT</label><input type="number" name="WS_PORT" value="{{cfg.WS_PORT}}"></div><div class="field"><label>WS PATH</label><input name="WS_PATH" value="{{cfg.WS_PATH}}"></div></div><div><label class="toggle"><input type="checkbox" name="ENABLE_XHTTP" {{'checked' if cfg.ENABLE_XHTTP|lower=='true' else ''}}>xHTTP</label><div class="field"><label>XHTTP PORT</label><input type="number" name="XHTTP_PORT" value="{{cfg.XHTTP_PORT}}"></div><div class="field"><label>XHTTP PATH</label><input name="XHTTP_PATH" value="{{cfg.XHTTP_PATH}}"></div></div></div><div class="form-grid"><div class="field"><label>XHTTP MODE</label><select name="XHTTP_MODE">{% for x in ['auto','packet-up','stream-up','stream-one'] %}<option {{'selected' if cfg.XHTTP_MODE==x else ''}}>{{x}}</option>{% endfor %}</select></div><div class="field"><label>LOG LEVEL</label><select name="LOG_LEVEL">{% for x in ['warning','info','debug','error','none'] %}<option {{'selected' if cfg.LOG_LEVEL==x else ''}}>{{x}}</option>{% endfor %}</select></div></div><button class="btn primary">Lưu & Restart</button></form></div>
<div class="card span5 pad"><div class="section-head"><div><div class="section-title">Bảo mật Panel</div><div class="section-sub">Đổi thông tin đăng nhập quản trị</div></div><div class="iconbox">⌾</div></div><form method="post" action="{{url_for('change_password')}}"><input type="hidden" name="csrf" value="{{csrf_token()}}"><div class="field"><label>MẬT KHẨU HIỆN TẠI</label><input type="password" name="current_password" required></div><div class="field"><label>MẬT KHẨU MỚI</label><input type="password" name="new_password" minlength="10" placeholder="Ít nhất 10 ký tự" required></div><button class="btn">Đổi mật khẩu</button></form><div class="divider"></div><div class="section-sub">Panel HTTPS :{{panel_port}} · Secure cookie · CSRF enabled</div></div>
{% if usage.last_error %}<div class="card span12 pad"><div class="section-head"><div><div class="section-title">Guard warning</div><div class="section-sub">Phát hiện lỗi ở dịch vụ quota guard</div></div><span class="pill bad">Warning</span></div><div class="warning">{{usage.last_error}}</div></div>{% endif %}
<div id="logs" class="card span12 pad"><div class="section-head"><div><div class="section-title">System logs</div><div class="section-sub">Nhật ký Xray gần nhất</div></div><a href="/" class="btn">Làm mới</a></div><div class="log">{{logs}}</div></div>
</section><div class="foot">Xray Control · Direct VLESS · Data quota + Device/IP limit · {{cfg.DOMAIN}}</div></div></main><nav class="mobile-nav"><a href="#overview">Tổng quan</a><a href="#devices">Thiết bị</a><a href="#connection">Kết nối</a><a href="#settings">Cấu hình</a><a href="#logs">Log</a></nav></div>'''

def render_page(body_tmpl, title, **ctx):
    body = render_template_string(body_tmpl, **ctx)
    return render_template_string(BASE_HTML, body=body, title=title)


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        if not csrf_ok():
            flash("Phiên biểu mẫu không hợp lệ. Hãy thử lại.", "error")
        elif request.form.get("username", "") == ADMIN_USER and ADMIN_HASH and check_password_hash(ADMIN_HASH, request.form.get("password", "")):
            session.clear(); session["authenticated"] = True; session["csrf"] = secrets.token_urlsafe(32); session.permanent = True
            return redirect(url_for("dashboard"))
        else:
            time.sleep(0.35); flash("Sai tài khoản hoặc mật khẩu.", "error")
    return render_page(LOGIN_BODY, "Đăng nhập")


@app.post("/logout")
@login_required
def logout():
    if csrf_ok():
        session.clear()
    return redirect(url_for("login"))


@app.get("/")
@login_required
def dashboard():
    cfg = load_xray_env()
    usage = load_usage()
    up = int(usage.get("uplink", 0) or 0); down = int(usage.get("downlink", 0) or 0); total = up + down
    limit_gb = parse_limit(cfg); limit_bytes = limit_gb * 1024**3
    percent = (total / limit_bytes * 100.0) if limit_bytes > 0 else None
    traffic_base = max(1, total)
    up_percent = up / traffic_base * 100.0
    down_percent = down / traffic_base * 100.0
    quota_ring = min(100.0, max(0.0, percent or 0.0))
    try:
        updated_ts = int(usage.get("updated_at", 0) or 0)
        updated_text = time.strftime("%d/%m %H:%M", time.localtime(updated_ts)) if updated_ts else "Chưa có dữ liệu"
    except Exception:
        updated_text = "Không rõ"
    try: device_limit = max(0, int(cfg.get("DEVICE_LIMIT", "0") or 0))
    except Exception: device_limit = 0
    online_ips = usage.get("online_ips", {}) if isinstance(usage.get("online_ips"), dict) else {}
    blocked = set(usage.get("blocked_ips", []) if isinstance(usage.get("blocked_ips"), list) else [])
    devices = []
    for ip, ts in sorted(online_ips.items(), key=lambda kv: str(kv[0])):
        try: stamp = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(int(ts)))
        except Exception: stamp = "N/A"
        devices.append({"ip": ip, "last_seen": stamp, "blocked": ip in blocked})
    return render_page(
        DASH_BODY, "Dashboard", cfg=cfg, state=service_state(), guard_state=service_state(GUARD_SERVICE),
        enabled=service_enabled(), uptime=uptime_text(), version=xray_version(), links=links_text(),
        logs=recent_logs(), panel_port=panel_cfg.get("PANEL_HTTPS_PORT", "9443"), usage=usage,
        used_up=human_bytes(up), used_down=human_bytes(down), used_total=human_bytes(total),
        limit_text=(f"{limit_gb:g} GB" if limit_gb > 0 else "∞"), limit_percent=percent,
        quota_ring=quota_ring, up_percent=up_percent, down_percent=down_percent, updated_text=updated_text,
        device_limit=device_limit, online_count=len(online_ips), devices=devices,
    )


@app.post("/service/<action>")
@login_required
def service_action(action):
    if not csrf_ok(): flash("CSRF token không hợp lệ.", "error"); return redirect(url_for("dashboard"))
    if action not in {"start", "stop", "restart"}: flash("Hành động không hợp lệ.", "error"); return redirect(url_for("dashboard"))
    if action == "stop":
        run(["systemctl", "stop", GUARD_SERVICE], timeout=10)
        rc, out = run(["systemctl", "stop", SERVICE], timeout=20)
    else:
        rc, out = run(["systemctl", action, SERVICE], timeout=20)
        if rc == 0:
            run(["systemctl", "restart", GUARD_SERVICE], timeout=15)
    flash(f"Đã {action} Xray." if rc == 0 else f"Lỗi: {out[-500:]}", "ok" if rc == 0 else "error")
    return redirect(url_for("dashboard"))


@app.post("/config")
@login_required
def save_config():
    if not csrf_ok(): flash("CSRF token không hợp lệ.", "error"); return redirect(url_for("dashboard"))
    backup = XRAY_ENV.read_text(encoding="utf-8")
    try:
        updates = validate_config(request.form); save_xray_env(updates)
        rc, out = run(["systemctl", "restart", SERVICE], timeout=20); time.sleep(1)
        if rc != 0 or service_state() != "active": raise RuntimeError(out[-800:] or "Xray không active sau restart")
        flash("Đã lưu cấu hình và restart Xray.", "ok")
    except Exception as exc:
        XRAY_ENV.write_text(backup, encoding="utf-8"); os.chmod(XRAY_ENV, 0o600); run(["systemctl", "restart", SERVICE], timeout=20)
        flash(f"Không áp dụng được cấu hình, đã khôi phục bản cũ: {exc}", "error")
    return redirect(url_for("dashboard"))


@app.post("/limits")
@login_required
def save_limits():
    if not csrf_ok(): flash("CSRF token không hợp lệ.", "error"); return redirect(url_for("dashboard"))
    try:
        limit = float(request.form.get("DATA_LIMIT_GB", "0")); devices = int(request.form.get("DEVICE_LIMIT", "0"))
        if limit < 0 or limit > 1000000: raise ValueError("Data limit không hợp lệ.")
        if devices < 0 or devices > 1000: raise ValueError("Device limit phải từ 0 đến 1000.")
        save_xray_env({"DATA_LIMIT_GB": f"{limit:g}", "DEVICE_LIMIT": str(devices)})
        run(["systemctl", "restart", GUARD_SERVICE], timeout=15)
        flash("Đã lưu giới hạn Data/thiết bị. Guard sẽ áp dụng trong vài giây.", "ok")
    except Exception as exc:
        flash(f"Không lưu được giới hạn: {exc}", "error")
    return redirect(url_for("dashboard"))


@app.post("/data/reset")
@login_required
def reset_data():
    if not csrf_ok(): flash("CSRF token không hợp lệ.", "error"); return redirect(url_for("dashboard"))
    run(["systemctl", "stop", GUARD_SERVICE], timeout=15)
    cfg = load_xray_env(); api = f"127.0.0.1:{cfg.get('XRAY_API_PORT','10085')}"; binary = BASE_DIR / "xray"
    run([str(binary), "api", "statsquery", f"--server={api}", "-pattern", f"user>>>{USER_EMAIL}>>>traffic>>>", "-reset"], timeout=6)
    state = load_usage(); state["uplink"] = 0; state["downlink"] = 0; state["quota_exceeded"] = False; state["last_error"] = ""; save_usage(state)
    if QUOTA_FLAG.exists(): QUOTA_FLAG.unlink()
    run(["systemctl", "restart", SERVICE], timeout=20); run(["systemctl", "start", GUARD_SERVICE], timeout=15)
    flash("Đã reset Data về 0 và mở lại quota.", "ok")
    return redirect(url_for("dashboard"))


@app.post("/uuid/new")
@login_required
def regen_uuid():
    if not csrf_ok(): flash("CSRF token không hợp lệ.", "error"); return redirect(url_for("dashboard"))
    run(["systemctl", "stop", GUARD_SERVICE], timeout=15)
    new_id = str(uuidlib.uuid4()); save_xray_env({"XRAY_UUID": new_id})
    state = empty_usage(); save_usage(state)
    try: QUOTA_FLAG.unlink()
    except FileNotFoundError: pass
    rc, out = run(["systemctl", "restart", SERVICE], timeout=20); run(["systemctl", "start", GUARD_SERVICE], timeout=15)
    flash(f"Đã tạo UUID mới và reset Data: {new_id}" if rc == 0 else f"Đổi UUID thất bại: {out[-500:]}", "ok" if rc == 0 else "error")
    return redirect(url_for("dashboard"))


@app.post("/xray/update")
@login_required
def update_xray():
    if not csrf_ok(): flash("CSRF token không hợp lệ.", "error"); return redirect(url_for("dashboard"))
    py = BASE_DIR / "venv" / "bin" / "python"
    rc, out = run([str(py), str(BASE_DIR / "download-xray.py")], timeout=120)
    if rc == 0:
        r2, out2 = run(["systemctl", "restart", SERVICE], timeout=20); rc = r2; out += out2
        run(["systemctl", "restart", GUARD_SERVICE], timeout=15)
    flash("Đã cập nhật Xray và restart." if rc == 0 else f"Cập nhật thất bại: {out[-800:]}", "ok" if rc == 0 else "error")
    return redirect(url_for("dashboard"))


@app.post("/password")
@login_required
def change_password():
    global ADMIN_HASH
    if not csrf_ok(): flash("CSRF token không hợp lệ.", "error"); return redirect(url_for("dashboard"))
    current = request.form.get("current_password", ""); new = request.form.get("new_password", "")
    if not ADMIN_HASH or not check_password_hash(ADMIN_HASH, current): flash("Mật khẩu hiện tại không đúng.", "error"); return redirect(url_for("dashboard"))
    if len(new) < 10: flash("Mật khẩu mới phải có ít nhất 10 ký tự.", "error"); return redirect(url_for("dashboard"))
    from werkzeug.security import generate_password_hash
    new_hash = generate_password_hash(new, method="scrypt")
    lines = PANEL_ENV.read_text(encoding="utf-8").splitlines(); out = []; found = False
    for line in lines:
        if line.startswith("PANEL_PASSWORD_HASH="): out.append("PANEL_PASSWORD_HASH=" + new_hash); found = True
        else: out.append(line)
    if not found: out.append("PANEL_PASSWORD_HASH=" + new_hash)
    PANEL_ENV.write_text("\n".join(out) + "\n", encoding="utf-8"); os.chmod(PANEL_ENV, 0o600); ADMIN_HASH = new_hash
    flash("Đã đổi mật khẩu panel.", "ok"); return redirect(url_for("dashboard"))


@app.get("/health")
def health():
    return {"ok": True}, 200


if __name__ == "__main__":
    app.run("127.0.0.1", 9090, debug=False)
