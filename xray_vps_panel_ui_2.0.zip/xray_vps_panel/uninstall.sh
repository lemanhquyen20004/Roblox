#!/usr/bin/env bash
set -e
[ "$(id -u)" -eq 0 ] || { echo "Run as root"; exit 1; }
systemctl disable --now xray-vps-direct.service xray-vps-panel.service xray-vps-guard.service 2>/dev/null || true
rm -f /etc/systemd/system/xray-vps-direct.service /etc/systemd/system/xray-vps-panel.service /etc/systemd/system/xray-vps-guard.service
rm -f /etc/nginx/conf.d/xray-vps-panel.conf
rm -f /etc/letsencrypt/renewal-hooks/deploy/xray-vps-direct.sh
rm -rf /opt/xray-vps-direct
systemctl daemon-reload
nginx -t >/dev/null 2>&1 && systemctl reload nginx 2>/dev/null || true
echo "Đã gỡ Xray VPS Direct + Panel + Guard. Chứng chỉ Let's Encrypt được giữ lại."
