#!/usr/bin/env python3
import json
import os
import subprocess
import time
from pathlib import Path

from dotenv import dotenv_values

BASE_DIR = Path(__file__).resolve().parent
ENV_PATH = BASE_DIR / ".env"
STATE_PATH = BASE_DIR / "usage_state.json"
LOCK_PATH = BASE_DIR / "usage_state.lock"
QUOTA_FLAG = BASE_DIR / "quota.block"
XRAY_BIN = BASE_DIR / "xray"
SERVICE = "xray-vps-direct.service"
USER_EMAIL = "vps-user@local"
POLL_SECONDS = 5
SENTINEL_IP = "192.0.2.1"

try:
    import fcntl
except ImportError:
    fcntl = None


def run(cmd, timeout=8):
    try:
        p = subprocess.run(cmd, cwd=BASE_DIR, text=True, capture_output=True, timeout=timeout)
        return p.returncode, (p.stdout or "") + (p.stderr or "")
    except Exception as exc:
        return 1, str(exc)


def load_cfg():
    return {k: (v or "") for k, v in dotenv_values(ENV_PATH).items()}


def as_float(value, default=0.0):
    try:
        return float(value)
    except Exception:
        return default


def as_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def empty_state():
    return {
        "uplink": 0,
        "downlink": 0,
        "updated_at": 0,
        "online_ips": {},
        "first_seen": {},
        "blocked_ips": [],
        "quota_exceeded": False,
        "last_error": "",
    }


def load_state():
    try:
        obj = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        state = empty_state()
        state.update(obj if isinstance(obj, dict) else {})
        return state
    except Exception:
        return empty_state()


def save_state(state):
    tmp = STATE_PATH.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(state, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    os.chmod(tmp, 0o600)
    os.replace(tmp, STATE_PATH)


def locked_state_update(fn):
    LOCK_PATH.touch(exist_ok=True)
    with LOCK_PATH.open("r+") as lockf:
        if fcntl:
            fcntl.flock(lockf.fileno(), fcntl.LOCK_EX)
        state = load_state()
        result = fn(state)
        save_state(state)
        if fcntl:
            fcntl.flock(lockf.fileno(), fcntl.LOCK_UN)
        return result


def parse_stats_json(text):
    try:
        data = json.loads(text)
    except Exception:
        return 0, 0
    up = down = 0
    for item in data.get("stat", []) if isinstance(data, dict) else []:
        name = str(item.get("name", ""))
        try:
            value = int(item.get("value", 0))
        except Exception:
            value = 0
        if name.endswith(">>>uplink"):
            up += value
        elif name.endswith(">>>downlink"):
            down += value
    return up, down


def query_traffic(api_addr):
    pattern = f"user>>>{USER_EMAIL}>>>traffic>>>"
    rc, out = run([str(XRAY_BIN), "api", "statsquery", f"--server={api_addr}", "-pattern", pattern, "-reset"], timeout=5)
    if rc != 0:
        return None, out[-800:]
    return parse_stats_json(out), ""


def query_online_ips(api_addr):
    rc, out = run([str(XRAY_BIN), "api", "statsonlineiplist", f"--server={api_addr}", "-email", USER_EMAIL], timeout=5)
    if rc != 0:
        return None, out[-800:]
    try:
        data = json.loads(out)
        ips = data.get("ips", {}) if isinstance(data, dict) else {}
        if isinstance(ips, dict):
            clean = {}
            for ip, ts in ips.items():
                try:
                    clean[str(ip)] = int(ts)
                except Exception:
                    clean[str(ip)] = int(time.time())
            return clean, ""
    except Exception as exc:
        return None, f"Invalid online-IP JSON: {exc}"
    return {}, ""


def xray_pid():
    rc, out = run(["systemctl", "show", SERVICE, "-p", "MainPID", "--value"], timeout=3)
    return out.strip() if rc == 0 else "0"


def apply_source_blocks(api_addr, blocked):
    # The source-IP API needs at least one source argument. TEST-NET-1 is used as
    # a harmless sentinel when there is nothing to block.
    ips = sorted(set(blocked)) or [SENTINEL_IP]
    cmd = [str(XRAY_BIN), "api", "sib", f"--server={api_addr}", "-outbound=block", "-ruletag=deviceLimitBlock", "-reset"] + ips
    rc, out = run(cmd, timeout=7)
    if rc != 0:
        # On the very first run the rule tag may not exist yet, so -reset can
        # fail while removing it. Retry once without -reset to create it.
        cmd2 = [str(XRAY_BIN), "api", "sib", f"--server={api_addr}", "-outbound=block", "-ruletag=deviceLimitBlock"] + ips
        rc2, out2 = run(cmd2, timeout=7)
        if rc2 == 0:
            return True, out2[-800:]
        return False, (out + " | retry: " + out2)[-800:]
    return True, out[-800:]


def maybe_toggle_quota(limit_bytes, total):
    exceeded = limit_bytes > 0 and total >= limit_bytes
    current = QUOTA_FLAG.exists()
    if exceeded and not current:
        QUOTA_FLAG.write_text("quota exceeded\n", encoding="utf-8")
        run(["systemctl", "restart", SERVICE], timeout=20)
        return True, exceeded
    if not exceeded and current:
        try:
            QUOTA_FLAG.unlink()
        except FileNotFoundError:
            pass
        run(["systemctl", "restart", SERVICE], timeout=20)
        return True, exceeded
    return False, exceeded


def main():
    last_blocks = None
    last_pid = None
    while True:
        try:
            cfg = load_cfg()
            api_port = as_int(cfg.get("XRAY_API_PORT"), 10085)
            api_addr = f"127.0.0.1:{api_port}"
            data_limit_gb = max(0.0, as_float(cfg.get("DATA_LIMIT_GB"), 0.0))
            device_limit = max(0, as_int(cfg.get("DEVICE_LIMIT"), 0))
            now = int(time.time())

            traffic, traffic_err = query_traffic(api_addr)
            ips, ips_err = query_online_ips(api_addr)

            def update(state):
                if traffic is not None:
                    state["uplink"] = max(0, int(state.get("uplink", 0))) + max(0, int(traffic[0]))
                    state["downlink"] = max(0, int(state.get("downlink", 0))) + max(0, int(traffic[1]))
                if ips is not None:
                    state["online_ips"] = ips
                    first_seen = state.get("first_seen", {}) if isinstance(state.get("first_seen"), dict) else {}
                    for ip in ips:
                        first_seen.setdefault(ip, now)
                    # Keep only currently online entries, making a reconnect a fresh device slot.
                    state["first_seen"] = {ip: first_seen.get(ip, now) for ip in ips}
                state["updated_at"] = now
                errs = [e for e in (traffic_err, ips_err) if e]
                state["last_error"] = " | ".join(errs)[-1200:]
                return state

            state = locked_state_update(update)
            total = int(state.get("uplink", 0)) + int(state.get("downlink", 0))
            limit_bytes = int(data_limit_gb * 1024 * 1024 * 1024)
            restarted, exceeded = maybe_toggle_quota(limit_bytes, total)

            online = state.get("online_ips", {}) if isinstance(state.get("online_ips"), dict) else {}
            first_seen = state.get("first_seen", {}) if isinstance(state.get("first_seen"), dict) else {}
            active = list(online.keys())
            if device_limit > 0 and len(active) > device_limit:
                ordered = sorted(active, key=lambda ip: (int(first_seen.get(ip, now)), ip))
                blocked = ordered[device_limit:]
            else:
                blocked = []

            pid = xray_pid()
            if restarted:
                time.sleep(2)
                pid = xray_pid()
                last_pid = None
            if blocked != last_blocks or pid != last_pid:
                ok, msg = apply_source_blocks(api_addr, blocked)
                if ok:
                    last_blocks = list(blocked)
                    last_pid = pid
                else:
                    def set_error(st):
                        st["last_error"] = ("Device-limit rule: " + msg)[-1200:]
                    locked_state_update(set_error)

            def finalize(st):
                st["blocked_ips"] = list(blocked)
                st["quota_exceeded"] = bool(exceeded)
                st["updated_at"] = int(time.time())
            locked_state_update(finalize)

        except Exception as exc:
            try:
                def err(st):
                    st["last_error"] = str(exc)[-1200:]
                    st["updated_at"] = int(time.time())
                locked_state_update(err)
            except Exception:
                pass
        time.sleep(POLL_SECONDS)


if __name__ == "__main__":
    main()
