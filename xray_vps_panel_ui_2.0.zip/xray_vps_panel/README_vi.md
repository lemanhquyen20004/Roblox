# Xray VLESS Direct VPS + Web Panel + Data/Device Limit

Bản dành cho Ubuntu/Debian VPS, chạy VLESS trực tiếp, **không cần Cloudflare**.

## Giao diện Xray Control 2.0

- Dashboard dark glass hiện đại, bố cục bento.
- Sidebar desktop + thanh điều hướng cố định trên mobile.
- KPI Xray/Data/thiết bị/quota, vòng quota và biểu đồ traffic trực quan.
- Link VLESS mặc định được làm mờ, có nút Hiện/Ẩn và Copy.
- Responsive tối ưu điện thoại, tablet và desktop.
- Không dùng CDN hay thư viện giao diện bên ngoài; CSS/JS nằm ngay trong Panel.

## Tính năng

- VLESS WebSocket + TLS trên cổng 443.
- VLESS xHTTP + TLS trên cổng 8443 (có thể đổi khi cài).
- Web Panel HTTPS mặc định `https://domain:9443`.
- Xem **Data đã dùng**: Upload, Download và Tổng.
- Đặt **Data limit theo GB**. Khi đạt giới hạn, user tự bị khóa; tăng hạn mức hoặc Reset Data sẽ mở lại.
- Đặt **Device limit** theo số public source IP đang online mà Xray ghi nhận.
- Xem danh sách IP online và IP đang bị chặn do vượt device limit.
- Data được lưu trong `usage_state.json`, không mất khi restart Xray/VPS.
- Nút **Reset Data** trên Panel.
- Start / Stop / Restart, cập nhật Xray Core, đổi UUID/path/port/xHTTP mode/log level.
- Xem/copy link VLESS, log Xray, uptime, phiên bản Core.
- Đăng nhập quản trị, HTTPS, CSRF, secure cookie.
- Let's Encrypt + systemd tự chạy Xray, Panel và Guard sau reboot.

## Cách tính

`Data đã dùng = uplink + downlink` của user VLESS trên cả WS và xHTTP. Xray StatsService cung cấp bộ đếm per-user; Guard lấy delta định kỳ rồi lưu vào file riêng, vì vậy restart Xray không xóa tổng đã lưu.

`Device limit` dùng danh sách **IP online** của Xray. Đây là giới hạn theo public IP, không phải hardware ID: nhiều máy cùng NAT/Wi‑Fi có thể được tính là 1; một thiết bị đổi public IP có thể được nhìn như IP khác.

Mặc định khi cài:

```text
DATA_LIMIT_GB=0   # unlimited
DEVICE_LIMIT=0    # unlimited
```

Sau đó chỉnh ngay trên Panel.

## Cài đặt

```bash
unzip xray_vps_panel_limits.zip
cd xray_vps_panel
sudo bash install.sh
```

Yêu cầu: domain A record trỏ thẳng IPv4 VPS; nếu dùng DNS Cloudflare thì để **DNS only** cho chế độ direct.

## Dịch vụ

```bash
systemctl status xray-vps-direct
systemctl status xray-vps-panel
systemctl status xray-vps-guard
journalctl -u xray-vps-direct -f
journalctl -u xray-vps-guard -f
```

File quan trọng:

```text
/opt/xray-vps-direct/.env
/opt/xray-vps-direct/usage_state.json
/opt/xray-vps-direct/vless-links.txt
```

Xray API chỉ nghe localhost trên `127.0.0.1:10085`; không mở cổng API ra Internet.
